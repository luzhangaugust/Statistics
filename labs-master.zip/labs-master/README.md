# labs

R Markdown files for the labs in the Coursera [Statistics with R](https://www.coursera.org/specializations/statistics) specialization.